Seja bem vindo ao calculateTaxes-1.0.0!

Essa é uma versão executável da calculadora de impostos, que pode ser utilizada sem a necessidade 
de rodar o código do projeto.

Como foi gerada no sistema operacional Windows 10, devido a algumas limitações de compatibilidade
entre GraalVM, java 17 e visual studio, é necessário que o arquivo java-0.0.1-SNAPSHOT.jar esteja
no mesmo diretório deste executável para que ele funcione corretamente.

Como usar:

1 - Após descompactar o arquivo CalculateTaxes.zip para extrair o diretório CalculateTaxes,
ao dar duplo clique no executável java-0.0.1-SNAPSHOT.exe um terminal será aberto onde o usuário
poderá utilizar os comandos internos do Spring Shell (help, stacktrace, clear, quit, history e version)
ou os comandos criados para a calculadora de impostos, calculateTaxesFile e calculateTaxes.

2 - Para utilizar o comando calculateTaxes basta digitar calculateTaxes e inserir uma entrada em formato
JSON. Como por exemplo:

calculateTaxes '[{\"operation\":\"buy\",\"unit-cost\":10.00,\"quantity\":100},{\"operation\":\"sell\",\"unit-cost\":15.00,\"quantity\":50},{\"operation\":\"sell\",\"unit-cost\":15.00,\"quantity\":50}]'

O programa irá realizar o cálculo dos impostos das operações inseridas e irá retornar um json com os valores.
Exemplo:

[{"tax":0.00},{"tax":0.00},{"tax":0.00}]

3 - Para utilizar o comando calculateTaxesFile basta digitar calculateTaxesFile e inserir o nome de um
arquivo que contenha as operações que se deseja calcular os impostos. O arquivo precisa estar no mesmo
diretório que o executável, e no formato .txt. Dentro da pasta que se encontra o executável e o .jar 
encontra-se um arquivo de exemplo, operations.txt, que pode ser utilizado como base. Exemplo:

calculateTaxesFile operations.txt

O programa retornará os impostos. Exemplo:

[{"tax":0.00},{"tax":80000.00},{"tax":0.00},{"tax":60000.00}]
[{"tax":0.00},{"tax":0.00},{"tax":0.00},{"tax":0.00},{"tax":3000.00},{"tax":0.00},{"tax":0.00},{"tax":3700.00},{"tax":0.00}]

A vantagem do uso do arquivo é que podem ser processadas várias linhas de uma vez, com várias sequências
de operações diferentes. O programa retornará o cálculo de impostos para cada linha de entrada em uma 
linha diferente. Se no arquivo de entrada existirem 3 linhas, o programa retornará 3 linhas com impostos.

A cada execução o programa cria ou atualiza (caso já exista) o arquivo calculateTaxes.log, com um log
da aplicação que pode ser consultado depois para ver todos os comandos que foram executados nela.

Muito obrigado, e até logo!